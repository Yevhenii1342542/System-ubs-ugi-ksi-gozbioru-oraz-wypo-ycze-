<?php
                require_once('db.php');
                $nazwa = $_POST['nazwa'];
                $kw3="SELECT id_ksiazki,tytul, autor FROM `ksiazki` WHERE tytul LIKE '$nazwa%';";
                if(isset($_POST['znajdz'])){
                    
                
                $result = mysqli_query($conn,$kw3);
                while($row=mysqli_fetch_array($result)){
                    echo "<ul>
                    <li>Nr:$row[0]  Tytul:$row[1]  Autor:$row[2]</li>
                    </ul>";
                    

                }}
                $imie = $_POST['name'];
                $nazwisko = $_POST['surname'];
                $nr = $_POST['nrks'];
                $kww = "UPDATE `czytelnik` SET `id_wyp`= $nr WHERE imie LIKE '$imie' AND nazwisko LIKE '$nazwisko';";
                if(isset($_POST['wypozycz'])){
                    mysqli_query($conn,$kww);
                    echo "<h4>Książka została wypożyczona</h4>";
                }
               
                ?>