-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1
-- Час створення: Квт 09 2026 р., 14:10
-- Версія сервера: 10.4.32-MariaDB
-- Версія PHP: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База даних: `biblioteka`
--

-- --------------------------------------------------------

--
-- Структура таблиці `bibliotekarz`
--

CREATE TABLE `bibliotekarz` (
  `id_bib` int(11) NOT NULL,
  `login` varchar(50) DEFAULT NULL,
  `haslo` varchar(50) DEFAULT NULL,
  `imie` text DEFAULT NULL,
  `nazwisko` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Дамп даних таблиці `bibliotekarz`
--

INSERT INTO `bibliotekarz` (`id_bib`, `login`, `haslo`, `imie`, `nazwisko`) VALUES
(1, 'bibliotekarz1', 'qwerty', 'Danil', 'Kharyna');

-- --------------------------------------------------------

--
-- Структура таблиці `czytelnik`
--

CREATE TABLE `czytelnik` (
  `id_czytelnika` int(11) NOT NULL,
  `login` varchar(50) DEFAULT NULL,
  `haslo` varchar(50) DEFAULT NULL,
  `imie` text DEFAULT NULL,
  `nazwisko` text DEFAULT NULL,
  `id_wyp` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Дамп даних таблиці `czytelnik`
--

INSERT INTO `czytelnik` (`id_czytelnika`, `login`, `haslo`, `imie`, `nazwisko`, `id_wyp`) VALUES
(6, 'dryslo', 'penis', 'Aschab', 'Tamajew', 10),
(7, 'fsdfsf', 'fsdf', 'dfdfs', 'fdsfs', NULL),
(8, '123', '321', 'maksym', 'Gandzubas', 8),
(9, 'arkasha', 'wsxcde', 'Arkadij', 'Parawozow', 16);

-- --------------------------------------------------------

--
-- Структура таблиці `ksiazki`
--

CREATE TABLE `ksiazki` (
  `id_ksiazki` int(11) NOT NULL,
  `tytul` varchar(50) DEFAULT NULL,
  `autor` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Дамп даних таблиці `ksiazki`
--

INSERT INTO `ksiazki` (`id_ksiazki`, `tytul`, `autor`) VALUES
(1, 'Krew elfów', 'Andrzej Sapkowski'),
(2, 'Gra o tron', 'George R.R. Martin'),
(3, 'Gołoborze', 'Maciej Siembieda'),
(4, 'Harry Potter i Kamień Filozoficzny', 'J.K. Rowling'),
(5, 'Wyścig z czasem. Komisarz Oczko (33)', 'Tomasz Wandzel'),
(6, 'Fałszywe wrażenie', 'Jeffrey Archer'),
(7, 'Tajemnice zbrodni', 'Ewa Ornacka'),
(8, 'Gen zła', 'Katarzyna Wolwowicz'),
(9, 'Zacisze 13', 'Olga Rudnicka'),
(10, 'Chłopiec z Kresów', 'Tomasz Wandzel'),
(11, 'Alicja w krainie czasów', 'Ałbena Grabowska'),
(12, 'Antygona', 'Sofokles'),
(13, 'Wyspa Pingwinów', 'Anatol France'),
(14, 'Zew Cthulhu', 'H.P. Lovecraft'),
(15, 'Kolobok', 'Arsenij Jaceniuk'),
(16, 'Tareodory z wasiukiwki', 'Genadij Dryst'),
(17, 'Biblia', 'Bóg');

--
-- Індекси збережених таблиць
--

--
-- Індекси таблиці `bibliotekarz`
--
ALTER TABLE `bibliotekarz`
  ADD PRIMARY KEY (`id_bib`);

--
-- Індекси таблиці `czytelnik`
--
ALTER TABLE `czytelnik`
  ADD PRIMARY KEY (`id_czytelnika`);

--
-- Індекси таблиці `ksiazki`
--
ALTER TABLE `ksiazki`
  ADD PRIMARY KEY (`id_ksiazki`);

--
-- AUTO_INCREMENT для збережених таблиць
--

--
-- AUTO_INCREMENT для таблиці `bibliotekarz`
--
ALTER TABLE `bibliotekarz`
  MODIFY `id_bib` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT для таблиці `czytelnik`
--
ALTER TABLE `czytelnik`
  MODIFY `id_czytelnika` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT для таблиці `ksiazki`
--
ALTER TABLE `ksiazki`
  MODIFY `id_ksiazki` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
