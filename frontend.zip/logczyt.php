<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Czytelnik</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <section id="user">
            <h4 id="txt">Logowanie jako czytelnik</h4>
            <a href="logczyt2.php"><button id="zalog">Zaloguj się</button></a><br>
            <a href="reg.php"><button>Załóż konto</button></a>
        </section>
    <section id="main">
        <section id="logo">
            <a href="index.php"><img src="logo.png" alt="logo"></a>
        </section>
        <section id="tresc">
            <h4>
                Witamy w bibliotece online <br>
                Czytaj książki za darmo, w dowolnym czasie i z dowolnego miejsca
            </h4>
        </section>
        <section id="knopki">
            <a href="logczyt.php"><button>Jestem czytelnikiem</button></a>
            <a href="logbib.php"><button>Jestem bibliotekarz</button></a>
        </section>
        
</section>
    
</body>
</html>
