<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Biblioteka</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <section id="ksiazki">
            <h4>Polecane książki</h4>
            <table>
                <tr>
                    <th>Nr</th>
                    <th>Tytuł</th>
                    <th>Autor</th>
                </tr>
                <?php
                $conn=mysqli_connect('localhost','root','','biblioteka');
                $kw2="SELECT id_ksiazki, tytul, autor FROM ksiazki ORDER BY RAND() LIMIT 5;";
                $res = mysqli_query($conn, $kw2);
                while($row=mysqli_fetch_array($res)){
                    echo "<tr>
                    <td>$row[0]</td>
                    <td>$row[1]</td>
                    <td>$row[2]</td>
                    </tr>";
                }
                mysqli_close($conn);
                
                ?>
            </table>
            <form action="biblioteka.php" method="post" >
                <input type="text" placeholder="Wyszukaj książkę" id="wyszukaj" name="nazwa">
                <button name="znajdz" id="znajdz">Wyszukaj</button><br>
                <ul>
                <?php
                error_reporting(0);
                require_once('db.php');
                $nazwa = $_POST['nazwa'];
                $kw3="SELECT id_ksiazki,tytul, autor FROM `ksiazki` WHERE tytul LIKE '$nazwa%';";
                if(isset($_POST['znajdz'])){
                    
                
                $result = mysqli_query($conn,$kw3);
                while($row=mysqli_fetch_array($result)){
                    echo "<li><b>Nr: </b>$row[0]  <b>Tytul: </b>$row[1]  <b>Autor: </b>$row[2]</li>";
                    

                }}
                ?></ul>
                <h4>Wypożyczenie</h4>
                <input type="number" placeholder= "numer książki" id="nrks" name="nrks"><br>
                <input type="text" placeholder="Imię" id="name" name="name"><button name="wypozycz" id="wypozycz">Wypożycz</button><br>
                <input type="text" placeholder="Nazwisko" id="surname" name="surname"><br>
                
                
                <?php
                error_reporting(0);
                require_once('db.php');
                $imie = $_POST['name'];
                $nazwisko = $_POST['surname'];
                $nr = $_POST['nrks'];
                $kww = "UPDATE `czytelnik` SET `id_wyp`= $nr WHERE imie LIKE '$imie' AND nazwisko LIKE '$nazwisko';";
                if(isset($_POST['wypozycz'])){
                    mysqli_query($conn,$kww);
                    echo "<h4>Książka została wypożyczona</h4>";
                }
               
                ?>
                
            </form>
            
        </section>
    <section id="main">
        <section id="logo">
            <a href="index.php"><img src="logo.png" alt="logo"></a>
        </section>
        <section id="tresc">
            <h4>
                Witamy w bibliotece online <br>
                Czytaj książki za darmo, w dowolnym czasie i z dowolnego miejsca
            </h4>
        </section>
        <section id="knopki">
            <a href="logczyt.php"><button>Jestem czytelnikiem</button></a>
            <a href="logbib.php"><button>Jestem bibliotekarz</button></a>
        </section>
        
</section>
    
</body>
</html>