<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dodawanie</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <section id="main">
        <section id="logo">
            <a href="index.php"><img src="logo.png" alt="logo"></a>
        </section>
        <section id="tresc">
            <h4>
                Witamy w bibliotece online <br>
                Czytaj książki za darmo, w dowolnym czasie i z dowolnego miejsca
            </h4>
        </section>
        <section id="knopki">
            <a href="logczyt.php"><button >Jestem czytelnikiem</button></a>
            <a href="logbib.php"><button>Jestem bibliotekarz</button></a>
        </section>
        
</section>
<section id= "bib">
    <h4 id="napis">Wpisz tytuł oraz autora</h4>
    <form action="dodawanie.php" method="post">
        <input type="text" placeholder="Tytuł" name="tytul"><br>
        <input type="text" placeholder="Autor" name="autor"><br>
        <a href="bibliotekarz.php"><button id="nazad" name="nazad"><</button></a>
        <button name= "dodaj" id="dodaj">Dodaj książkę</button>
        <?php
        if(isset($_POST['nazad'])){
            header("location:http://localhost/biblioteka/bibliotekarz.php");
        }
        ?>
        <?php
        error_reporting(0);
        $conn = mysqli_connect('localhost','root','','biblioteka');
        $tytul = $_POST['tytul'];
        $autor = $_POST['autor'];
        $kw= "INSERT INTO `ksiazki`(`id_ksiazki`, `tytul`, `autor`) VALUES (null,'$tytul','$autor');";
        if(isset($_POST['dodaj'])){
            mysqli_query($conn,$kw);
        }
        mysqli_close($conn);
        ?>
    </form>

            
        </section>
</body>
</html>
