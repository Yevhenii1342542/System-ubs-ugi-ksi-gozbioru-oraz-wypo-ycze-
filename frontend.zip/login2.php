<?php
$conn = mysqli_connect('localhost', 'root', '', 'biblioteka');
$login = $_POST['login'];
$haslo = $_POST['haslo'];
$kw = "SELECT * FROM `bibliotekarz` WHERE login = '$login' AND haslo = '$haslo';";
$res = mysqli_query($conn, $kw);
if($res -> num_rows > 0 ){
   
        header("location: http://localhost/biblioteka/bibliotekarz.php");
    
}
else{
    header("location: http://localhost/biblioteka/err2.php");
}
mysqli_close($conn);
?>