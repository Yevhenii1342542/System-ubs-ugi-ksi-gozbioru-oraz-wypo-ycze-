<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="st.css">
</head>

<body>
    <h1>Nieprawidlowy login lub hasło</h1>
    <a href="logbib.php"><button>Spróbuj ponownie</button></a>
</body>
</html>