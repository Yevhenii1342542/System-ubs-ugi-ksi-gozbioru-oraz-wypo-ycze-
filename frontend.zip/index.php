<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Wybór użytkownika</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <section id="main">
        <section id="logo">
            <img src="logo.png" alt="logo">
        </section>
        <section id="tresc">
            <h4>
                Witamy w bibliotece online <br>
                Czytaj książki za darmo, w dowolnym czasie i z dowolnego miejsca
            </h4>
        </section>
        <section id="knopki">
            <a href="logczyt.php"><button >Jestem czytelnikiem</button></a>
            <a href="logbib.php"><button>Jestem bibliotekarz</button></a>
        </section>
        
</section>
<section id= "menu">
            <h4>Wybierz opcje logowania</h4>
        </section>
</body>
</html>
