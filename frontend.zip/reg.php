<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rejestarcja</title>
    <link rel="stylesheet" href="style.css">
    
</head>
<body>
    <section id="user2">
            <h4 id="txt">Załóż konto jako czytelnik</h4>
            <form action="reg.php" method="post">
                <input type="text" id="imie" name="imie" placeholder="Imię"><br>
                <input type="text" id="nazwisko" name="nazwisko" placeholder="Nazwisko"><br>
        <input type="text" id="login" name="login" placeholder="Login"><br>
        <input type="text" name="haslo" placeholder="Hasło"><br>
        <button name="reg" type="submit">Załóż konto</button>
        
    </form>
     <?php
     error_reporting(0);
     $conn = mysqli_connect('localhost','root','','biblioteka');   
    $imie = $_POST['imie'];
    $nazwisko = $_POST['nazwisko'];
    $login = $_POST['login'];
    $haslo = $_POST['haslo'];
    $kw1 = "INSERT INTO `czytelnik`(`id_czytelnika`, `login`, `haslo`, `imie`, `nazwisko`) VALUES (null,'$login','$haslo','$imie','$nazwisko');";
    if(isset($_POST['reg'])){
        
        
        mysqli_query($conn, $kw1);
         header("Location: http://localhost/biblioteka/logczyt2.php");
    exit();
    }
    mysqli_close($conn);
   
    ?>
   
        </section>
    <section id="main">
        <section id="logo">
            <a href="index.php"><img src="logo.png" alt="logo"></a>
        </section>
        <section id="tresc">
            <h4>
                Witamy w bibliotece online <br>
                Czytaj książki za darmo, w dowolnym czasie i z dowolnego miejsca
            </h4>
        </section>
        <section id="knopki">
            <a href="logczyt.php"><button>Jestem czytelnikiem</button></a>
            <a href="logbib.php"><button>Jestem bibliotekarz</button></a>
        </section>
        
</section>
    
</body>
</html>