<?php
$conn = mysqli_connect('localhost', 'root', '', 'biblioteka');
$login = $_POST['login'];
$haslo = $_POST['haslo'];
$kw = "SELECT * FROM `czytelnik` WHERE login = '$login' AND haslo = '$haslo';";
$res = mysqli_query($conn, $kw);
if($res -> num_rows > 0 ){
   
        header("location: http://localhost/biblioteka/biblioteka.php");
    
}
else{
    header("location: http://localhost/biblioteka/err.php");
}
mysqli_close($conn);
?>