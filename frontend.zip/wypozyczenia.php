<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Wypożyczenia</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <section id="main">
        <section id="logo">
            <a href="index.php"><img src="logo.png" alt="logo"></a>
        </section>
        <section id="tresc">
            <h4>
                Witamy w bibliotece online <br>
                Czytaj książki za darmo, w dowolnym czasie i z dowolnego miejsca
            </h4>
        </section>
        <section id="knopki">
            <a href="logczyt.php"><button >Jestem czytelnikiem</button></a>
            <a href="logbib.php"><button>Jestem bibliotekarz</button></a>
        </section>
        
</section>
<section id= "bib">
    <h4 id="napis">Wszystkie wypożyczenia</h4>
    <table id="tab">
        <tr>
            <th>Imię</th>
            <th>Nazwisko</th>
            <th>Tytuł</th>
            <th>Autor</th>
        </tr>
        <?php
        $conn = mysqli_connect('localhost','root','','biblioteka');
        $kw = "SELECT imie, nazwisko, tytul, autor FROM `czytelnik` JOIN ksiazki ON czytelnik.id_wyp = ksiazki.id_ksiazki WHERE id_wyp IS NOT null;";
        $res = mysqli_query($conn,$kw);
        while($row=mysqli_fetch_array($res)){
            echo "<tr>
            <td>$row[0]</td>
            <td>$row[1]</td>
            <td>$row[2]</td>
            <td>$row[3]</td>
            </tr>";
        }
        mysqli_close($conn);
        ?>
    </table><br>
    <a href="bibliotekarz.php"><button id="nazad1" name="nazad">Wróć</button></a>
    <?php
        if(isset($_POST['nazad'])){
            header("location:http://localhost/biblioteka/bibliotekarz.php");
        }
        ?>
    
            
        </section>
</body>
</html>
