<?php
$server = "localhost";
$user = "root";
$password = "";
$db = "biblioteka";
$conn = mysqli_connect($server, $user, $password, $db);
?>
